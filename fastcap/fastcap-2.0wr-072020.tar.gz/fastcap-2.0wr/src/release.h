
#ifndef RELEASE_H
#define RELEASE_H

/* Date and version info.  These are rewritten in the FastCap version
 * supplied with the XicTools.
 * The mkwinpkg file in the packager also has a date code.
 */
#define FCVERSION "2.0wr (18Sep92, rev 071020)"
#define ID_STRING  "071020"

#endif

