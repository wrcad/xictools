#!/bin/bash



spice3 -b test1.sp &> test1.out
grep gmin test1.out
grep abort test1.out
grep Nan test1.out
echo test1
spice3 -b test2.sp &> test2.out 
grep gmin test2.out
grep abort test2.out
grep Nan test2.out
echo test2
spice3 -b test3.sp &> test3.out 
grep gmin test3.out
grep abort test3.out
grep Nan test3.out
echo test3
spice3 -b test4.sp &> test4.out 
grep gmin test4.out
grep abort test4.out
grep Nan test4.out
echo test4
spice3 -b test5.sp &> test5.out 
grep gmin test5.out
grep abort test5.out
grep Nan test5.out
echo test5
spice3 -b test6.sp &> test6.out 
grep gmin test6.out
grep abort test6.out
grep Nan test6.out
echo test6
spice3 -b test7.sp &> test7.out
grep gmin test7.out
grep abort test7.out
grep Nan test7.out
echo test7
spice3 -b test8.sp &> test8.out
grep gmin test8.out
grep abort test8.out
grep Nan test8.out
echo test8
spice3 -b inv_dc.sp &> inv_dc.out
grep gmin inv_dc.out
grep abort inv_dc.out
grep Nan inv_dc.out
echo inv_dc 
spice3 -b inv_tr.sp &> inv_tr.out
grep gmin inv_tr.out
grep abort inv_tr.out
grep Nan inv_tr.out
echo inv_tr
spice3 -b ring51_42.sp &> ring51_42.out 
grep gmin ring51_42.out
grep abort ring51_42.out
grep Nan ring51_42.out
echo ring51_42

