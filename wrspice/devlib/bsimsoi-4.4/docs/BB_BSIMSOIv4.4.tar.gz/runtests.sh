#!/bin/bash

hspice test1.sp > test1.out
hspice test2.sp > test2.out
hspice test3.sp > test3.out
hspice test4.sp > test4.out
hspice test5.sp > test5.out
hspice test6.sp > test6.out
hspice test7.sp > test7.out
hspice test8.sp > test8.out
hspice inverter_dc.sp > inv_dc.out
hspice inverter_tr.sp > inv_tr.out
hspice ring_osc.sp > ring_osc.out

rm *.sw0
rm *.tr0
rm *.pa0
rm *.st0
rm *.val
rm *.ic0
















