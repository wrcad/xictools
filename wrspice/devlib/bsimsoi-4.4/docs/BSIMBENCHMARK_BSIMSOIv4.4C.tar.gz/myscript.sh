#!/bin/bash

spice3 -b test1.sp > test1.out
spice3 -b test2.sp > test2.out
spice3 -b test3.sp > test3.out
spice3 -b test4.sp > test4.out
spice3 -b test5.sp > test5.out
spice3 -b test6.sp > test6.out
spice3 -b test7.sp > test7.out
spice3 -b test8.sp > test8.out
spice3 -b inv_tr.sp > inv_tr.out
spice3 -b inv_dc.sp > inv_dc.out
spice3 -b ring51_42.sp > ring51_42.out


















