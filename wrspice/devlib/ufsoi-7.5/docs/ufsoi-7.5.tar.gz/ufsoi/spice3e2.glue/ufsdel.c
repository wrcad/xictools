/**********
Copyright 1997 University of Florida.  All rights reserved.
Author: Min-Chie Jeng (For SPICE3E2)
File: ufsdel.c
**********/

#include "spice.h"
#include <stdio.h>
#include "util.h"
#include "ufsdef.h"
#include "sperror.h"
#include "gendefs.h"
#include "suffix.h"


int
UFSdelete(inModel, name, inInst)
GENmodel *inModel;
IFuid name;
GENinstance **inInst;
{
UFSinstance **fast = (UFSinstance**)inInst;
UFSmodel *model = (UFSmodel*)inModel;
UFSinstance **prev = NULL;
UFSinstance *here;

    for (; model ; model = model->UFSnextModel) 
    {    prev = &(model->UFSinstances);
         for (here = *prev; here ; here = *prev) 
	 {    if (here->UFSname == name || (fast && here==*fast))
	      {   *prev= here->UFSnextInstance;
                  FREE(here);
                  return(OK);
              }
              prev = &(here->UFSnextInstance);
         }
    }
    return(E_NODEV);
}
