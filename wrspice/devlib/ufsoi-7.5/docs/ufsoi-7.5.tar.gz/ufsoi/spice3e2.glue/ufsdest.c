/**********
Copyright 1997 University of Florida.  All rights reserved.
Author: Min-Chie Jeng (For SPICE3E2)
File: ufsdest.c
**********/

#include "spice.h"
#include <stdio.h>
#include "util.h"
#include "ufsdef.h"
#include "suffix.h"

void
UFSdestroy(inModel)
GENmodel **inModel;
{
UFSmodel **model = (UFSmodel**)inModel;
UFSinstance *here;
UFSinstance *prev = NULL;
UFSmodel *mod = *model;
UFSmodel *oldmod = NULL;

    for (; mod ; mod = mod->UFSnextModel)
    {    if(oldmod) FREE(oldmod);
         oldmod = mod;
         prev = (UFSinstance *)NULL;
         for (here = mod->UFSinstances; here; here = here->UFSnextInstance)
	 {    if (prev)
	      {   FREE(prev);
	      }
              prev = here;
         }
         if(prev)
	 {  FREE(prev);
	 }
    }
    if(oldmod) FREE(oldmod);
    *model = NULL;
    return;
}

