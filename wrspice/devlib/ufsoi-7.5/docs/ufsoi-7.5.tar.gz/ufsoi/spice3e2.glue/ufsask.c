/**********
Copyright 1997 University of Florida.  All rights reserved.
Author: Min-Chie Jeng (For SPICE3E2)
File: ufsask.c
**********/

#include "spice.h"
#include <stdio.h>
#include <math.h>
#include "ifsim.h"
#include "cktdefs.h"
#include "devdefs.h"
#include "ufsdef.h"
#include "sperror.h"
#include "util.h"
#include "suffix.h"

int
UFSask(ckt, inst, which, value, select)
CKTcircuit *ckt;
GENinstance *inst;
int which;
IFvalue *value;
IFvalue *select;
{
struct ufsAPI_InstData *pInst;
struct ufsAPI_OPData *pOpInfo;
UFSinstance *here = (UFSinstance*)inst;
int Error;
double ParamValue;

    pInst = here->pInst;
    pOpInfo = here->pOpInfo;
    if ((pInst == NULL) || (pOpInfo == NULL))
        return(E_BADPARM);
	
    switch(which) 
    {   case UFS_L:
        case UFS_W:
        case UFS_M:
        case UFS_AS:
        case UFS_AD:
        case UFS_AB:
        case UFS_PSJ:          /* 4.5 */
        case UFS_PDJ:          /* 4.5 */
        case UFS_NRS:
        case UFS_NRD:
        case UFS_NRB:
        case UFS_RTH:
        case UFS_CTH:
        case UFS_TEMP:
	    Error = ufsGetInstParam(pInst, which, &ParamValue);
	    if (Error)
		return(E_BADPARM);
	    value->rValue = ParamValue;
	    return(OK);
        /* case UFS_BJT:
	    Error = ufsGetInstParam(pInst, which, &ParamValue);
	    if (Error)
		return(E_BADPARM);
	    value->iValue = (int) ParamValue;
            return(OK);                                             4.5 */

        case UFS_OFF:
            value->iValue = here->UFSoff;
            return(OK);
        case UFS_IC_VBS:
            value->rValue = here->UFSicVBS;
            return(OK);
        case UFS_IC_VDS:
            value->rValue = here->UFSicVDS;
            return(OK);
        case UFS_IC_VGFS:
            value->rValue = here->UFSicVGFS;
            return(OK);
        case UFS_IC_VGBS:
            value->rValue = here->UFSicVGBS;
            return(OK);
        case UFS_DNODE:
            value->iValue = here->UFSdNode;
            return(OK);
        case UFS_GNODE:
            value->iValue = here->UFSgNode;
            return(OK);
        case UFS_SNODE:
            value->iValue = here->UFSsNode;
            return(OK);
        case UFS_BNODE:
            value->iValue = here->UFSbNode;
            return(OK);
        case UFS_BGNODE:
            value->iValue = here->UFSbgNode;
            return(OK);
        case UFS_TNODE:
            value->iValue = here->UFStNode;
            return(OK);
        case UFS_DNODEPRIME:
            value->iValue = here->UFSdNodePrime;
            return(OK);
        case UFS_SNODEPRIME:
            value->iValue = here->UFSsNodePrime;
            return(OK);
        case UFS_BNODEPRIME:
            value->iValue = here->UFSbNodePrime;
            return(OK);

	/* OP point parameters */
	default:
	    Error = ufsGetOpParam(pOpInfo, which, &ParamValue);
	    if (Error)
		return(E_BADPARM);
	    value->rValue = ParamValue;
    }
    return(OK);
}

