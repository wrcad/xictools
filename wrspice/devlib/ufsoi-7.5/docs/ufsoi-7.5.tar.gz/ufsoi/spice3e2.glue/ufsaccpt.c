/**********
Copyright 1990 Regents of the University of California.  All rights reserved.
Author: 1997 Min-Chie Jeng
File: ufsaccpt.c
**********/

#include "spice.h"
#include <stdio.h>
#include "cktdefs.h"
#include "ufsdef.h"
#include "sperror.h"
#include "suffix.h"


int
UFSaccept(ckt, inModel)
register CKTcircuit *ckt;
GENmodel *inModel;
{
register UFSmodel *model = (UFSmodel*)inModel;
double Percent;

    for (; model != NULL; model = model->UFSnextModel)
    {    if (model->UFSdebug == 3)
	 {   Percent = ckt->CKTtime / ckt->CKTfinalTime * 100.0;
	     fprintf(stderr, "Time = %g (%4.2g%%) \n", ckt->CKTtime, Percent);
	     return (OK);
	 }
    }
    return(OK);
}

