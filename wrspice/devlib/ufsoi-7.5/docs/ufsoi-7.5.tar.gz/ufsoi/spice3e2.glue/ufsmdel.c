/**********
Copyright 1997 University of Florida.  All rights reserved.
Author: Min-Chie Jeng (For SPICE3E2)
File: ufsmdel.c
**********/

#include "spice.h"
#include <stdio.h>
#include "util.h"
#include "ufsdef.h"
#include "sperror.h"
#include "suffix.h"

int
UFSmDelete(inModel, modname, kill)
GENmodel **inModel;
IFuid modname;
GENmodel *kill;
{
UFSmodel **model = (UFSmodel**)inModel;
UFSmodel *modfast = (UFSmodel*)kill;
UFSinstance *here;
UFSinstance *prev = NULL;
UFSmodel **oldmod;

    oldmod = model;
    for (; *model ; model = &((*model)->UFSnextModel)) 
    {    if ((*model)->UFSmodName == modname || 
             (modfast && *model == modfast))
	     goto delgot;
         oldmod = model;
    }
    return(E_NOMOD);

delgot:
    *oldmod = (*model)->UFSnextModel; /* cut deleted device out of list */
    for (here = (*model)->UFSinstances; here; here = here->UFSnextInstance)
    {    if(prev) FREE(prev);
         prev = here;
    }
    if(prev) FREE(prev);
    FREE(*model);
    return(OK);
}

