/***********
Copyright 1997 University of Florida.  All rights reserved.
Author: Min-Chie Jeng (For SPICE3E2)
File: ufstemp.c
**********/

#include "spice.h"
#include <stdio.h>
#include <math.h>
#include "smpdefs.h"
#include "cktdefs.h"
#include "ufsdef.h"
#include "util.h"
#include "const.h"
#include "sperror.h"
#include "suffix.h"

/* ARGSUSED */
int
UFStempUpdate(inModel, ckt)
GENmodel *inModel;
CKTcircuit *ckt;
{
register UFSmodel *model = (UFSmodel*) inModel;
register UFSinstance *here;
register struct ufsAPI_InstData *pInst;
register struct ufsAPI_ModelData *pModel;
register struct ufsTDModelData *pTempModel;
struct ufsAPI_EnvData Env;
double T;
int SH;                                                                          /* 4.5 */

    /*  loop through all the UFS device models */
    Env.Temperature = ckt->CKTtemp;
    Env.Tnom = ckt->CKTnomTemp;
    for (; model != NULL; model = model->UFSnextModel)
    {    pModel = model->pModel;
	 model->UFSvcrit = CONSTvt0 * log(CONSTvt0 / (CONSTroot2 * 1.0e-14));

         /* loop through all the instances of the model */
         for (here = model->UFSinstances; here != NULL;
              here = here->UFSnextInstance) 
	 {    pInst = here->pInst;
	      pInst->pDebug = NULL;
	      pTempModel = pInst->pTempModel;
	      T = ckt->CKTtemp;
	      SH = 1;                                                            /* 4.5 */
	      ufsTempEffect(pModel, pInst, &Env, T, SH);                         /* 4.5 */
         }
    }
    return(OK);
}

