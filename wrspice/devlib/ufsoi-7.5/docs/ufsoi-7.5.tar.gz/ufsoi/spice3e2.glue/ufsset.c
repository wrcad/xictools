/**********
Copyright 1997 University of Florida.  All rights reserved.
Author: Min-Chie Jeng (For SPICE3E2)
File: ufsset.c
**********/

#include "spice.h"
#include <stdio.h>
#include <math.h>
#include "smpdefs.h"
#include "cktdefs.h"
#include "ufsdef.h"
#include "util.h"
#include "const.h"
#include "sperror.h"
#include "suffix.h"

int
UFSsetup(matrix, inModel, ckt, states)
register SMPmatrix *matrix;
register GENmodel *inModel;
register CKTcircuit *ckt;
int *states;
{
register UFSmodel *model = (UFSmodel*)inModel;
register UFSinstance *here;
register struct ufsAPI_ModelData *pModel;
register struct ufsAPI_InstData *pInst;
struct ufsAPI_EnvData Env;
int error;
CKTnode *tmp;
double tmp1, tmp2, T1;

    Env.Temperature = ckt->CKTtemp;
    Env.Tnom = ckt->CKTnomTemp;
    /*  loop through all the UFS device models */
    for(; model != NULL; model = model->UFSnextModel )
    {   /* Default value Processing for UFS MOSFET Models */
        if (!model->UFSparamChkGiven) 
            model->UFSparamChk = 0;
        if (!model->UFSdebugGiven) 
            model->UFSdebug = 0;

	pModel = model->pModel;
	ufsDefaultModelParam(pModel, &Env);
	ufsInitModel(pModel, &Env);

        /* loop through all the instances of the model */
        for (here = model->UFSinstances; here != NULL ;
             here = here->UFSnextInstance) 
	{   /* allocate a chunk of the state vector */
            here->UFSstates = *states;
            *states += UFSnumStates;

            /* perform the parameter defaulting */
            if (!here->UFSicVBSGiven)
                here->UFSicVBS = 0;
            if (!here->UFSicVDSGiven)
                here->UFSicVDS = 0;
            if (!here->UFSicVGFSGiven)
                here->UFSicVGFS = 0;
            if (!here->UFSicVGBSGiven)
                here->UFSicVGBS = 0;

	    pInst = here->pInst;
	    ufsDefaultInstParam(pModel, pInst, &Env);
	    ufsInitInst(pModel, pInst, &Env);

            /* process drain series resistance */
            if ((pInst->DrainConductance > 0.0)
		&& (here->UFSdNodePrime == 0))
	    {   error = CKTmkVolt(ckt,&tmp,here->UFSname,"drain");
                if(error) return(error);
                here->UFSdNodePrime = tmp->number;
            }
	    else
	    {   here->UFSdNodePrime = here->UFSdNode;
            }
                   
            /* process source series resistance */
            if ((pInst->SourceConductance > 0.0)
		&& (here->UFSsNodePrime == 0)) 
	    {   error = CKTmkVolt(ckt, &tmp, here->UFSname, "source");
                if(error) return(error);
                here->UFSsNodePrime = tmp->number;
            }
	    else 
	    {   here->UFSsNodePrime = here->UFSsNode;
            }

            if ((pModel->Selft > 0) && (here->UFStNode == 0)) 
	    {   error = CKTmkVolt(ckt, &tmp, here->UFSname, "temp_node");
                if(error) return(error);
                here->UFStNode = tmp->number;
            }
	    else 
	    {   here->UFStNode = 0;
            }

            /* set the substrate (backgate) node to ground if not provided */
            if (here->UFSbgNode < 0)
	        here->UFSbgNode = 0;

            /* if bulk (nfdmod=2), tie the body node to back gate */                     /* 6.0bulk */
	    if (pModel->NfdMod == 2)                                                     /* 6.0bulk */ 
      	        {/* if 3, 4 or 5 nodes - don't care if B is specified */                 /* 6.0bulk */
                      /* check for well/substrate resistance */                          /* 6.0bulk */
	              if ((pInst->BodyConductance > 0.0) && (here->UFSbNodePrime == 0))  /* 6.0bulk */
	              {   error = CKTmkVolt(ckt,&tmp,here->UFSname,"body");              /* 6.0bulk */
                          if(error) return(error);                                       /* 6.0bulk */
                          here->UFSbNodePrime = tmp->number;                             /* 6.0bulk */
 	        	  here->UFSbNode = here->UFSbgNode;                              /* 6.0bulk */
                      }                                                                  /* 6.0bulk */
	              else                                                               /* 6.0bulk */
	              {   here->UFSbNodePrime = here->UFSbgNode;                         /* 6.0bulk */
 	        	  here->UFSbNode = here->UFSbgNode;                              /* 6.0bulk */
                      }                                                                  /* 6.0bulk */
	              pInst->BulkContact = 1;                                            /* 6.0bulk */
        	}                                                                        /* 6.0bulk */
            else /* set up for the SOI structure */
	    {
               /* process body series resistance */
               if (here->UFSbNode < 0)
               {   /* Floating body: 3 or 4 nodes */
	           error = CKTmkVolt(ckt,&tmp,here->UFSname,"body");
                   if(error) return(error);
                   here->UFSbNodePrime = tmp->number;
	           here->UFSbNode = here->UFSbNodePrime;
	           pInst->BulkContact = 0;   /*check vbs limit/convergence*/
               }
               else
	       {   /* With body contact: 5 nodes */
	           if ((pInst->BodyConductance > 0.0) && (here->UFSbNodePrime == 0)) 
	           {   error = CKTmkVolt(ckt,&tmp,here->UFSname,"body");
                       if(error) return(error);
                       here->UFSbNodePrime = tmp->number;
                   }
	           else 
	           {   here->UFSbNodePrime = here->UFSbNode;
                   }
	           pInst->BulkContact = 1;
               }
            }

        /* set Sparse Matrix Pointers */

/* macro to make elements with built in test for out of memory */
#define TSTALLOC(ptr,first,second) \
if((here->ptr = SMPmakeElt(matrix,here->first,here->second))==(double *)NULL){\
    return(E_NOMEM);\
}

            TSTALLOC(UFSGgPtr, UFSgNode, UFSgNode)     
            TSTALLOC(UFSGdpPtr, UFSgNode, UFSdNodePrime)     
            TSTALLOC(UFSGspPtr, UFSgNode, UFSsNodePrime)     
            TSTALLOC(UFSGbpPtr, UFSgNode, UFSbNodePrime)     
            TSTALLOC(UFSGgbPtr, UFSgNode, UFSbgNode)         

            TSTALLOC(UFSDPgPtr, UFSdNodePrime, UFSgNode)     
            TSTALLOC(UFSDPdpPtr, UFSdNodePrime, UFSdNodePrime)
            TSTALLOC(UFSDPspPtr, UFSdNodePrime, UFSsNodePrime)
            TSTALLOC(UFSDPbpPtr, UFSdNodePrime, UFSbNodePrime)
            TSTALLOC(UFSDPgbPtr, UFSdNodePrime, UFSbgNode)

            TSTALLOC(UFSSPgPtr, UFSsNodePrime, UFSgNode)     
            TSTALLOC(UFSSPdpPtr, UFSsNodePrime, UFSdNodePrime)
            TSTALLOC(UFSSPspPtr, UFSsNodePrime, UFSsNodePrime)
            TSTALLOC(UFSSPbpPtr, UFSsNodePrime, UFSbNodePrime)
            TSTALLOC(UFSSPgbPtr, UFSsNodePrime, UFSbgNode)

            TSTALLOC(UFSBPgPtr, UFSbNodePrime, UFSgNode)     
            TSTALLOC(UFSBPdpPtr, UFSbNodePrime, UFSdNodePrime)
            TSTALLOC(UFSBPspPtr, UFSbNodePrime, UFSsNodePrime)
            TSTALLOC(UFSBPbpPtr, UFSbNodePrime, UFSbNodePrime)
            TSTALLOC(UFSBPgbPtr, UFSbNodePrime, UFSbgNode)

            TSTALLOC(UFSGBgPtr, UFSbgNode, UFSgNode)         
            TSTALLOC(UFSGBdpPtr, UFSbgNode, UFSdNodePrime)
            TSTALLOC(UFSGBspPtr, UFSbgNode, UFSsNodePrime)
            TSTALLOC(UFSGBbpPtr, UFSbgNode, UFSbNodePrime)
            TSTALLOC(UFSGBgbPtr, UFSbgNode, UFSbgNode)

            TSTALLOC(UFSDdPtr, UFSdNode, UFSdNode)
            TSTALLOC(UFSDdpPtr, UFSdNode, UFSdNodePrime)
            TSTALLOC(UFSDPdPtr, UFSdNodePrime, UFSdNode)

            TSTALLOC(UFSSsPtr, UFSsNode, UFSsNode)
            TSTALLOC(UFSSspPtr, UFSsNode, UFSsNodePrime)
            TSTALLOC(UFSSPsPtr, UFSsNodePrime, UFSsNode)

            TSTALLOC(UFSBbPtr, UFSbNode, UFSbNode)
            TSTALLOC(UFSBbpPtr, UFSbNode, UFSbNodePrime)
            TSTALLOC(UFSBPbPtr, UFSbNodePrime, UFSbNode)

	    /* Thermal pointers */
            TSTALLOC(UFSTtPtr, UFStNode, UFStNode)
            TSTALLOC(UFSGtPtr, UFSgNode, UFStNode)           
            TSTALLOC(UFSDPtPtr, UFSdNodePrime, UFStNode)
            TSTALLOC(UFSSPtPtr, UFSsNodePrime, UFStNode)
            TSTALLOC(UFSBPtPtr, UFSbNodePrime, UFStNode)
            TSTALLOC(UFSGBtPtr, UFSbgNode, UFStNode)
            TSTALLOC(UFSTgPtr, UFStNode, UFSgNode)           
            TSTALLOC(UFSTdpPtr, UFStNode, UFSdNodePrime)
            TSTALLOC(UFSTspPtr, UFStNode, UFSsNodePrime)
            TSTALLOC(UFSTbpPtr, UFStNode, UFSbNodePrime)
            TSTALLOC(UFSTgbPtr, UFStNode, UFSbgNode)
        }
    }
    return(OK);
}  
