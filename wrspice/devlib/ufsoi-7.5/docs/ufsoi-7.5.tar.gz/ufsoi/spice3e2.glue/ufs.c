/**********
Copyright 1997 University of Florida.  All rights reserved.
Author: Min-Chie Jeng (For SPICE3E2)
File: ufs.c
**********/

#include "spice.h"
#include <stdio.h>
#include "devdefs.h"
#include "ufsdef.h"
#include "suffix.h"

IFparm UFSpTable[] = { /* parameters */
IOP( "l",   UFS_L,      IF_REAL   , "Length"),
IOP( "w",   UFS_W,      IF_REAL   , "Width"),
IOP( "m",   UFS_M,      IF_REAL   , "Number of gate fingers"),
IOP( "ad",  UFS_AD,     IF_REAL   , "Drain area"),
IOP( "as",  UFS_AS,     IF_REAL   , "Source area"),
IOP( "ab",  UFS_AB,     IF_REAL   , "Body area"),
IOP( "nrd", UFS_NRD,    IF_REAL   , "Number of squares in drain"),
IOP( "nrs", UFS_NRS,    IF_REAL   , "Number of squares in source"),
IOP( "nrb", UFS_NRB,    IF_REAL   , "Number of squares in body"),
IOP( "rth", UFS_RTH,    IF_REAL   , "Thermal resistance"),
IOP( "cth", UFS_CTH,    IF_REAL   , "Thermal capacitance"),
IOP( "pdj", UFS_PDJ,    IF_REAL   , "Drain junction perimeter"),                            /* 4.5 */
IOP( "psj", UFS_PSJ,    IF_REAL   , "Source junction perimeter"),                           /* 4.5 */
IOP( "off", UFS_OFF,    IF_FLAG   , "Device is initially off"),
IP(  "ic",  UFS_IC,     IF_REALVEC, "Vector of DS,GFS,GBS,BS initial voltages"),

OP( "Ich",  UFS_ICH,     IF_REAL,    "Channel current"),
OP( "Ibjt", UFS_IBJT,    IF_REAL,    "Parasitic bipolar current"),
OP( "Ir",   UFS_IR,      IF_REAL,    "Recombination current (B-S)"),
OP( "Igt",  UFS_IGT,     IF_REAL,    "Thermal generation current (B-D)"),
OP( "Igi",  UFS_IGI,     IF_REAL,    "Impact-ionization current"),
OP( "Igb",  UFS_IGB,     IF_REAL,    "Gate-to-body tunneling current"),                     /* 7.0Y */
OP( "Vbs",  UFS_VBS,     IF_REAL,    "Internal B-S voltage"),
OP( "Vbd",  UFS_VBD,     IF_REAL,    "Internal B-D voltage"),
OP( "Vgfs", UFS_VGFS,    IF_REAL,    "Internal GF-S voltage"),
OP( "Vgfd", UFS_VGFD,    IF_REAL,    "Internal GF-D voltage"),
OP( "Vgbs", UFS_VGBS,    IF_REAL,    "Internal GB-S voltage"),
OP( "Vds",  UFS_VDS,     IF_REAL,    "Internal D-S voltage"),

OP( "dId_dVgf", UFS_GDGF,    IF_REAL,    "dId_dVgf"),
OP( "dId_dVd",  UFS_GDD,     IF_REAL,    "dId_dVd"),
OP( "dId_dVgb", UFS_GDGB,    IF_REAL,    "dId_dVgb"),
OP( "dId_dVb",  UFS_GDB,     IF_REAL,    "dId_dVb"),
OP( "dId_dVs",  UFS_GDS,     IF_REAL,    "dId_dVs"),
OP( "dIr_dVb",  UFS_GRB,     IF_REAL,    "dIr_dVb"),
OP( "dIr_dVs",  UFS_GRS,     IF_REAL,    "dIr_dVs"),
OP( "dIgt_dVgf",UFS_GGTGF,   IF_REAL,    "dIgt_dVgf"),
OP( "dIgt_dVd", UFS_GGTD,    IF_REAL,    "dIgt_dVd"),
OP( "dIgt_dVgb",UFS_GGTGB,   IF_REAL,    "dIgt_dVgb"),
OP( "dIgt_dVb", UFS_GGTB,    IF_REAL,    "dIgt_dVb"),
OP( "dIgt_dVs", UFS_GGTS,    IF_REAL,    "dIgt_dVS"),
OP( "dIgi_dVgf",UFS_GGIGF,   IF_REAL,    "dIgi_dVgf"),
OP( "dIgi_dVd", UFS_GGID,    IF_REAL,    "dIgi_dVd"),
OP( "dIgi_dVgb",UFS_GGIGB,   IF_REAL,    "dIgi_dVgb"),
OP( "dIgi_dVb", UFS_GGIB,    IF_REAL,    "dIgi_dVb"),
OP( "dIgi_dVs", UFS_GGIS,    IF_REAL,    "dIgi_dVs"),
OP( "dIgb_dVgf",UFS_GGBGF,   IF_REAL,    "dIgb_dVgf"),                                    /* 7.0Y */
OP( "dIgb_dVd", UFS_GGBD,    IF_REAL,    "dIgb_dVd"),                                     /* 7.0Y */
OP( "dIgb_dVgb",UFS_GGBGB,   IF_REAL,    "dIgb_dVgb"),                                    /* 7.0Y */
OP( "dIgb_dVb", UFS_GGBB,    IF_REAL,    "dIgb_dVb"),                                     /* 7.0Y */
OP( "dIgb_dVs", UFS_GGBS,    IF_REAL,    "dIgb_dVs"),                                     /* 7.0Y */

OP( "Qgf",  UFS_QGF,     IF_REAL,    "Front-gate charge"),
OP( "Qd",   UFS_QD,      IF_REAL,    "Drain charge"),
OP( "Qgb",  UFS_QGB,     IF_REAL,    "Back-gate charge"),
OP( "Qb",   UFS_QB,      IF_REAL,    "Body charge"),
OP( "Qs",   UFS_QS,      IF_REAL,    "Source charge"),
OP( "Qn",   UFS_QN,      IF_REAL,    "Inversion layer charge"),                             /* 4.5 */
OP( "Ueff", UFS_UEFF,    IF_REAL,    "Field-effect mobility"),                              /* 4.5 */
OP( "Vtw",  UFS_VTW,     IF_REAL,    "Weak-inversion threshold voltage"),
OP( "Vts",  UFS_VTS,     IF_REAL,    "Strong-inversion threshold voltage"),
OP( "Vdsat",UFS_VDSAT,   IF_REAL,    "Drain saturation voltage"),

OP( "dQgf_dVgf",UFS_CGFGF,   IF_REAL,    "dQgf_dVgf"),
OP( "dQgf_dVd", UFS_CGFD,    IF_REAL,    "dQgf_dVd"),
OP( "dQgf_dVgb",UFS_CGFGB,   IF_REAL,    "dQgf_dVgb"),
OP( "dQgf_dVb", UFS_CGFB,    IF_REAL,    "dQgf_dVb"),
OP( "dQgf_dVs", UFS_CGFS,    IF_REAL,    "dQgf_dVs"),
OP( "dQd_dVgf", UFS_CDGF,    IF_REAL,    "dQd_dVgf"),
OP( "dQd_dVd",  UFS_CDD,     IF_REAL,    "dQd_dVd"),
OP( "dQd_dVgb", UFS_CDGB,    IF_REAL,    "dQd_dVgb"),
OP( "dQd_dVb",  UFS_CDB,     IF_REAL,    "dQd_dVb"),
OP( "dQd_dVs",  UFS_CDS,     IF_REAL,    "dQd_dVs"),
OP( "dQgb_Vgf", UFS_CGBGF,   IF_REAL,    "dQgb_dVgf"),
OP( "dQgb_dVd", UFS_CGBD,    IF_REAL,    "dQgb_dVd"),
OP( "dQgb_dVgb",UFS_CGBGB,   IF_REAL,    "dQgb_dVgb"),
OP( "dQgb_dVb", UFS_CGBB,    IF_REAL,    "dQgb_dVb"),
OP( "dQgb_dVs", UFS_CGBS,    IF_REAL,    "dQgb_dVs"),
OP( "dQb_dVgf", UFS_CBGF,    IF_REAL,    "dQb_dVgf"),
OP( "dQb_dVd",  UFS_CBD,     IF_REAL,    "dQb_dVd"),
OP( "dQb_dVgb", UFS_CBGB,    IF_REAL,    "dQb_dVgb"),
OP( "dQb_dVb",  UFS_CBB,     IF_REAL,    "dQb_dVb"),
OP( "dQb_dVs",  UFS_CBS,     IF_REAL,    "dQb_dVs"),
OP( "dQs_dVgf", UFS_CSGF,    IF_REAL,    "dQs_dVgf"),
OP( "dQs_dVd",  UFS_CSD,     IF_REAL,    "dQs_dVd"),
OP( "dQs_dVgb", UFS_CSGB,    IF_REAL,    "dQs_dVgb"),
OP( "dQs_dVb",  UFS_CSB,     IF_REAL,    "dQs_dVb"),
OP( "dQs_dVs",  UFS_CSS,     IF_REAL,    "dQs_dVs"),

OP( "le",   UFS_LE,      IF_REAL,    "Modulated channel length"),
OP( "power",UFS_POWER,   IF_REAL,    "Power dissipation"),
OP( "temp", UFS_TEMP,    IF_REAL,    "Device temperature"),
OP( "Rd",   UFS_RD,      IF_REAL,    "Drain resistance"),
OP( "Rs",   UFS_RS,      IF_REAL,    "Source resistance"),
OP( "Rb",   UFS_RB,      IF_REAL,    "Body resistance"),

OP( "dId_dT",  UFS_GDT,     IF_REAL,    "dId_dT"),
OP( "dIr_dT",  UFS_GRT,     IF_REAL,    "dIr_dT"),
OP( "dIgt_dT", UFS_GGTT,    IF_REAL,    "dIgt_dT"),
OP( "dIgi_dT", UFS_GGIT,    IF_REAL,    "dIgi_dT"),
OP( "dIgb_dT", UFS_GGBT,    IF_REAL,    "dIgb_dT"),                                        /* 7.0Y */
OP( "dQgf_dT", UFS_CGFT,    IF_REAL,    "dQgf_dT"),
OP( "dQd_dT",  UFS_CDT,     IF_REAL,    "dQd_dT"),
OP( "dQgb_dT", UFS_CGBT,    IF_REAL,    "dQgb_dT"),
OP( "dQb_dT",  UFS_CBT,     IF_REAL,    "dQb_dT"),
OP( "dQs_dT",  UFS_CST,     IF_REAL,    "dQs_dT"),
OP( "dP_dT",   UFS_GPT,     IF_REAL,    "dP_dT"),
OP( "dP_dVgf", UFS_GPGF,    IF_REAL,    "dP_dVgf"),
OP( "dP_dVd",  UFS_GPD,     IF_REAL,    "dP_dVd"),
OP( "dP_dVgb", UFS_GPGB,    IF_REAL,    "dP_dVgb"),
OP( "dP_dVb",  UFS_GPB,     IF_REAL,    "dP_dVb"),
OP( "dP_dVs",  UFS_GPS,     IF_REAL,    "dP_dVs"),
};

IFparm UFSmPTable[] = { /* model parameters */
IOP( "debug", UFS_MOD_DEBUG, IF_INTEGER, "Debugging flag"),
IOP( "paramchk", UFS_MOD_PARAMCHK, IF_INTEGER, "Model parameter checking selector"),
IOP( "selft", UFS_MOD_SELFT, IF_INTEGER, "Selft-heating flag"),
IOP( "body", UFS_MOD_BODY, IF_INTEGER, "Body condition selector"),

IOP( "vfbf", UFS_MOD_VFBF, IF_REAL,  "Front-gate flatband voltage"),
IOP( "vfbb", UFS_MOD_VFBB, IF_REAL,  "Back-gate flatband voltage"),
IOP( "wkf",  UFS_MOD_WKF,  IF_REAL,  "Front-gate work function difference"),
IOP( "wkb",  UFS_MOD_WKB,  IF_REAL,  "Back-gate work function difference"),
IOP( "nqff", UFS_MOD_NQFF, IF_REAL,  "Normalized front oxide fixed charge"),
IOP( "nqfb", UFS_MOD_NQFB, IF_REAL,  "Normalized back oxide fixed charge"),
IOP( "nsf",  UFS_MOD_NSF,  IF_REAL,  "Front surface state density"),
IOP( "nsb",  UFS_MOD_NSB,  IF_REAL,  "Back surface state density"),
IOP( "toxf", UFS_MOD_TOXF, IF_REAL,  "Front-gate oxide thickness in meters"),
IOP( "toxb", UFS_MOD_TOXB, IF_REAL,  "Back-gate oxide thickness in meters"),
IOP( "nsub", UFS_MOD_NSUB, IF_REAL,  "Substrate doping concentration"),
IOP( "ngate",UFS_MOD_NGATE,IF_REAL,  "Poly-gate doping concentration"),
IOP( "tpg",  UFS_MOD_TPG,  IF_INTEGER,"Type of gate material"),
IOP( "tps",  UFS_MOD_TPS,  IF_INTEGER,"Type of substrate material"),
IOP( "nds",  UFS_MOD_NDS,  IF_REAL,  "Source/drain doping density"),
IOP( "tb",   UFS_MOD_TB,   IF_REAL,  "Body film thickness"),
IOP( "nbody",UFS_MOD_NBODY,IF_REAL,  "Body film doping density"),
IOP( "lldd", UFS_MOD_LLDD, IF_REAL,  "Length of LDD region"),
IOP( "nldd", UFS_MOD_NLDD, IF_REAL,  "LDD/LDS doing density"),
IOP( "uo",   UFS_MOD_U0,   IF_REAL,  "Low-field mobility at Tnom"),
IOP( "theta",UFS_MOD_THETA,IF_REAL,  "Mobility reduction parameter"),
IOP( "bfact",UFS_MOD_BFACT,IF_REAL,  "Vds-averaging factor for mobility reduction"),
IOP( "vsat", UFS_MOD_VSAT, IF_REAL,  "Carrier saturation velocity"),
IOP( "alpha",UFS_MOD_ALPHA,IF_REAL,  "Impact-ionization parameter"),
IOP( "beta", UFS_MOD_BETA, IF_REAL,  "Impact-ionization parameter"),
IOP( "gamma",UFS_MOD_GAMMA,IF_REAL,  "BOX fringing field factor"),
IOP( "kappa",UFS_MOD_KAPPA,IF_REAL,  "BOX fringing field factor"),
IOP( "tauo", UFS_MOD_TAUO, IF_REAL,  "Carrier lifetime in LDD region"),
IOP( "jro",  UFS_MOD_JRO,  IF_REAL,  "Junction recombination current coefficient"),
IOP( "m",    UFS_MOD_M,    IF_REAL,  "Junction recombination slope factor"),
IOP( "ldiff",UFS_MOD_LDIFF,IF_REAL,  "Effective diffusion length in source/drain parameter"),
IOP( "seff", UFS_MOD_SEFF, IF_REAL,  "Effective combination velocity in source/drain"),
IOP( "fvbjt",UFS_MOD_FVBJT,IF_REAL,  "BJT current partitioning factor"),
IOP( "tnom", UFS_MOD_TNOM, IF_REAL,  "Parameter measurement temperature"),
IOP( "cgfdo",UFS_MOD_CGFDO,IF_REAL,  "Front-gate to drain overlap capacitance per width"),
IOP( "cgfso",UFS_MOD_CGFSO,IF_REAL,  "Front-gate to source overlap capacitance per width"),
IOP( "cgfbo",UFS_MOD_CGFBO,IF_REAL,  "Front-gate to bulk overlap capacitance per length"),
IOP( "rhosd",UFS_MOD_RHOSD,IF_REAL,  "Source/drain sheet resistance"),
IOP( "rhob", UFS_MOD_RHOB, IF_REAL,  "Body sheet resistance"),
IOP( "rd",   UFS_MOD_RD,   IF_REAL,  "Specific drain parasitic resistance"),
IOP( "rs",   UFS_MOD_RS,   IF_REAL,  "Specific source parasitic resistance"),
IOP( "rb",   UFS_MOD_RB,   IF_REAL,  "Total body parasitic resistance"),
IOP( "dl",   UFS_MOD_DL,   IF_REAL,  "Channel length reduction"),
IOP( "dw",   UFS_MOD_DW,   IF_REAL,  "Channel width reduction"),
IOP( "fnk",  UFS_MOD_FNK,  IF_REAL,  "Flicker noise coefficient"),
IOP( "fna",  UFS_MOD_FNA,  IF_REAL,  "Flicker noise exponent"),
IOP( "tf",   UFS_MOD_TF,   IF_REAL,  "Silicon film thickness"),
IOP( "thalo",UFS_MOD_THALO,IF_REAL,  "Halo thickness"),
IOP( "nbl",  UFS_MOD_NBL,  IF_REAL,  "Low body doping concentration"),
IOP( "nbh",  UFS_MOD_NBH,  IF_REAL,  "High doping body concentration"),
IOP( "nhalo",UFS_MOD_NHALO,IF_REAL,  "Halo doping centration"),
IOP( "tmax", UFS_MOD_TMAX, IF_REAL,  "Maximum allowable temperature"),
IOP( "imax", UFS_MOD_IMAX, IF_REAL,  "Explosion current"),
IOP( "bgidl",UFS_MOD_BGIDL,IF_REAL,  "Gate-induced drain leakage current parameter"),       /* 4.41 */
IOP( "ntr",  UFS_MOD_NTR,  IF_REAL,  "Effective trap density for reverse-biased tunneling"),/* 4.5 */
IOP( "bjt",  UFS_MOD_BJT,  IF_INTEGER,"Flag to turn on parasitic bipolar current"),         /* 4.5 */
IOP( "lrsce",UFS_MOD_LRSCE,IF_REAL,  "Reverse short-channel effect characteristic length"), /* 4.5r */
IOP( "nqfsw",UFS_MOD_NQFSW,IF_REAL,  "Sidewall fixed charge for narrow-width effect"),      /* 4.5r */
IOP( "qm",   UFS_MOD_QM,   IF_REAL,  "Energy quantization parameter"),                      /* 4.5qm */
IOP( "vo",   UFS_MOD_VO,   IF_REAL,  "Velocity overshoot parameter"),                       /* 5.0vo */
IOP( "mox",  UFS_MOD_MOX,  IF_REAL,  "Electron effective mass in oxide"),                   /* 7.0Y */
IOP( "svbe", UFS_MOD_SVBE, IF_REAL,  "Smoothing constant for the onset of Ivbe"),           /* 7.0Y */
IOP( "scbe", UFS_MOD_SCBE, IF_REAL,  "Smoothing constant for the onset of Icbe"),           /* 7.0Y */
IOP( "kd",   UFS_MOD_KD,   IF_REAL,  "Dielectric constant"),                                /* 7.0Y */
IOP( "gex",  UFS_MOD_GEX,  IF_REAL,  "Ge content in the relaxed SiGe buffer"),              /* 7.5W */
IOP( "sfact",UFS_MOD_SFACT,IF_REAL,  "Factor for spline smoothing"),                        /* 7.0Y */
IOP( "ffact",UFS_MOD_FFACT,IF_REAL,  "Factor for the onset voltage of Icbe"),               /* 7.0Y */
IP(  "nmos", UFS_MOD_NMOS, IF_FLAG,  "Flag to indicate n-channel"),
IP(  "pmos", UFS_MOD_PMOS, IF_FLAG,  "Flag to indicate p-channel"),
};

char *UFSnames[] = {
   "Drain",
   "Gate",
   "Source",
   "BackGate",
   "Bulk"
};

int	UFSnSize = NUMELEMS(UFSnames);
int	UFSpTSize = NUMELEMS(UFSpTable);
int	UFSmPTSize = NUMELEMS(UFSmPTable);
int	UFSiSize = sizeof(UFSinstance);
int	UFSmSize = sizeof(UFSmodel);


