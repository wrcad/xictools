/**********
Copyright 1997 University of Florida.  All rights reserved.
Author: Min-Chie Jeng (For SPICE3E2)
File: ufsdef.h
**********/

#ifndef UFS
#define UFS

#include "ifsim.h"
#include "gendefs.h"
#include "cktdefs.h"
#include "complex.h"
#include "noisedef.h"         
#include "ufs_api.h"         

typedef struct sUFSinstance
{
    struct sUFSmodel *UFSmodPtr;
    struct sUFSinstance *UFSnextInstance;
    IFuid UFSname;

    int UFSdNode;
    int UFSgNode;
    int UFSsNode;
    int UFSbgNode;
    int UFSbNode;
    int UFSdNodePrime;
    int UFSsNodePrime;
    int UFSbNodePrime;
    int UFStNode;
    struct ufsAPI_InstData *pInst;
    struct ufsAPI_OPData  *pOpInfo;

    int UFSoff;
    double UFSicVBS;
    double UFSicVDS;
    double UFSicVGFS;
    double UFSicVGBS;

    unsigned UFSicVBSGiven :1;
    unsigned UFSicVDSGiven :1;
    unsigned UFSicVGFSGiven :1;
    unsigned UFSicVGBSGiven :1;
    unsigned DeviceInitialized :1;

    double *UFSGgPtr;                
    double *UFSGdpPtr;                
    double *UFSGspPtr;                
    double *UFSGbpPtr;                
    double *UFSGgbPtr;                
    double *UFSDPgPtr;                
    double *UFSDPdpPtr;
    double *UFSDPspPtr;
    double *UFSDPbpPtr;
    double *UFSDPgbPtr;
    double *UFSSPgPtr;                
    double *UFSSPdpPtr;
    double *UFSSPspPtr;
    double *UFSSPbpPtr;
    double *UFSSPgbPtr;
    double *UFSBPgPtr;                
    double *UFSBPdpPtr;
    double *UFSBPspPtr;
    double *UFSBPbpPtr;
    double *UFSBPgbPtr;
    double *UFSGBgPtr;                
    double *UFSGBdpPtr;
    double *UFSGBspPtr;
    double *UFSGBbpPtr;
    double *UFSGBgbPtr;

    double *UFSDdPtr;
    double *UFSDdpPtr;
    double *UFSDPdPtr;
    double *UFSSsPtr;
    double *UFSSPsPtr;
    double *UFSSspPtr;
    double *UFSBbPtr;
    double *UFSBPbPtr;
    double *UFSBbpPtr;

    double *UFSTtPtr;
    double *UFSGtPtr;                 
    double *UFSDPtPtr;
    double *UFSSPtPtr;
    double *UFSBPtPtr;
    double *UFSGBtPtr;
    double *UFSTgPtr;                 
    double *UFSTdpPtr;
    double *UFSTspPtr;
    double *UFSTbpPtr;
    double *UFSTgbPtr;

    int UFSstates;     /* index into state table for this device */
#define UFSvbd UFSstates+ 0
#define UFSvbs UFSstates+ 1
#define UFSvgfs UFSstates+ 2
#define UFSvds UFSstates+ 3
#define UFSvgbs UFSstates+ 4

#define UFSqb UFSstates+ 5
#define UFScqb UFSstates+ 6
#define UFSqg UFSstates+ 7
#define UFScqg UFSstates+ 8
#define UFSqd UFSstates+ 9
#define UFScqd UFSstates+ 10
#define UFSqgb UFSstates+ 11
#define UFScqgb UFSstates+ 12
#define UFSqt UFSstates+ 13
#define UFScqt UFSstates+ 14

#define UFStemp UFSstates+ 15
#define UFSnumStates 16

/* indices to the array of UFS NOISE SOURCES */
#define UFSRDNOIZ       0
#define UFSRSNOIZ       1
#define UFSRBNOIZ       2
#define UFSIDNOIZ       3
#define UFSSJNOIZ       4
#define UFSDJNOIZ       5
#define UFSBJTNOIZ      6
#define UFSFLNOIZ       7
#define UFSTOTNOIZ      8
#define UFSNSRCS        9     /* the number of MOSFET(3) noise sources */

#ifndef NONOISE
    double UFSnVar[NSTATVARS][UFSNSRCS];
#else /* NONOISE */
        double **UFSnVar;
#endif /* NONOISE */

} UFSinstance ;

typedef struct sUFSmodel 
{
    int UFSmodType;
    struct sUFSmodel *UFSnextModel;
    UFSinstance *UFSinstances;
    IFuid UFSmodName; 

    int UFSparamChk;
    int UFSdebug;
    struct ufsAPI_ModelData *pModel;
    double UFSvcrit;
    unsigned UFSparamChkGiven :1;
    unsigned UFSdebugGiven :1;
    unsigned ModelInitialized :1;

} UFSmodel;

#include "ufsext.h"

#endif /*UFS*/


