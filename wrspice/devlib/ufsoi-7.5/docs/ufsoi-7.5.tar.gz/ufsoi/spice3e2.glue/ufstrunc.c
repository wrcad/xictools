/**********
Copyright 1997 University of Florida.  All rights reserved.
Author: Min-Chie Jeng (For SPICE3E2)
File: ufstrunc.c
**********/

#include "spice.h"
#include <stdio.h>
#include <math.h>
#include "cktdefs.h"
#include "ufsdef.h"
#include "sperror.h"
#include "suffix.h"


int
UFStrunc(inModel, ckt, timeStep)
GENmodel *inModel;
register CKTcircuit *ckt;
double *timeStep;
{
register UFSmodel *model = (UFSmodel*)inModel;
register UFSinstance *here;

#ifdef STEPDEBUG
    double debugtemp;
#endif /* STEPDEBUG */

    for (; model != NULL; model = model->UFSnextModel)
    {    for (here = model->UFSinstances; here != NULL;
	      here = here->UFSnextInstance)
	 {
#ifdef STEPDEBUG
              debugtemp = *timeStep;
#endif /* STEPDEBUG */
              CKTterr(here->UFSqb, ckt, timeStep);
              CKTterr(here->UFSqg, ckt, timeStep);
              CKTterr(here->UFSqd, ckt, timeStep);
#ifdef STEPDEBUG
              if(debugtemp != *timeStep)
	      {  printf("device %s reduces step from %g to %g\n",
                         here->UFSname, debugtemp, *timeStep);
              }
#endif /* STEPDEBUG */
        }
    }
    return(OK);
}
