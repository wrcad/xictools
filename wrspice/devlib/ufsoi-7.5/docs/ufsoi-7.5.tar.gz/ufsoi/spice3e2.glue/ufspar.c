/**********
Copyright 1997 University of Florida.  All rights reserved.
Author: Min-Chie Jeng (For SPICE3E2)
File: ufspar.c
**********/

#include "spice.h"
#include <stdio.h>
#include "ifsim.h"
#include "ufsdef.h"
#include "util.h"
#include "sperror.h"
#include "suffix.h"

int
UFSparam(param, value, inst, select)
int param;
IFvalue *value;
GENinstance *inst;
IFvalue *select;
{
struct ufsAPI_InstData *pInst;
UFSinstance *here = (UFSinstance*)inst;
double ParamValue;
int Error;

    if (here->DeviceInitialized == 0)
    {   here->pInst = ALLOC(struct ufsAPI_InstData, 1);
	if (here->pInst == NULL) 
            return(E_NOMEM);
        here->pOpInfo = ALLOC(struct ufsAPI_OPData, 1);
	if (here->pOpInfo == NULL)
            return(E_NOMEM);
        here->pInst->pTempModel = ALLOC(struct ufsTDModelData, 1);
	if (here->pInst->pTempModel == NULL)
            return(E_NOMEM);
	ufsInitInstFlag(here->pInst);
	here->DeviceInitialized = 1;
    }

    pInst = here->pInst;
    switch(param) 
    {   
        case UFS_OFF:
            here->UFSoff = value->iValue;
            break;
        case UFS_IC_VBS:
            here->UFSicVBS = value->rValue;
            here->UFSicVBSGiven = TRUE;
            break;
        case UFS_IC_VDS:
            here->UFSicVDS = value->rValue;
            here->UFSicVDSGiven = TRUE;
            break;
        case UFS_IC_VGFS:
            here->UFSicVGFS = value->rValue;
            here->UFSicVGFSGiven = TRUE;
            break;
        case UFS_IC_VGBS:
            here->UFSicVGBS = value->rValue;
            here->UFSicVGBSGiven = TRUE;
            break;
        case UFS_IC:
            switch(value->v.numValue){
                case 4:
                    here->UFSicVBS = *(value->v.vec.rVec+3);
                    here->UFSicVBSGiven = TRUE;
                case 3:
                    here->UFSicVGBS = *(value->v.vec.rVec+2);
                    here->UFSicVGBSGiven = TRUE;
                case 2:
                    here->UFSicVGFS = *(value->v.vec.rVec+1);
                    here->UFSicVGFSGiven = TRUE;
                case 1:
                    here->UFSicVDS = *(value->v.vec.rVec);
                    here->UFSicVDSGiven = TRUE;
                    break;
                default:
                    return(E_BADPARM);
            }
            break;

	/* Integer type parameters */
        /* case UFS_BJT:
	    ParamValue = (double) value->iValue;
	    Error = ufsSetInstParam(pInst, param, ParamValue);
	    if (Error)
                return(E_BADPARM);
	    return(0);                                           4.5 */

	/* double type parameters */
        default:
	    ParamValue = value->rValue;
	    Error = ufsSetInstParam(pInst, param, ParamValue);
	    if (Error)
                return(E_BADPARM);
    }
    return(OK);
}
