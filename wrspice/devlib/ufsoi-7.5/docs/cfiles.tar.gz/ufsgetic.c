/**********
Copyright 1997 University of Florida.  All rights reserved.
Author: Min-Chie Jeng (For SPICE3E2)
File: ufsgetic.c
**********/

#include "spice.h"
#include <stdio.h>
#include "cktdefs.h"
#include "ufsdef.h"
#include "sperror.h"
#include "suffix.h"


int
UFSgetic(inModel, ckt)
GENmodel *inModel;
CKTcircuit *ckt;
{
UFSmodel *model = (UFSmodel*)inModel;
UFSinstance *here;

    for (; model ; model = model->UFSnextModel) 
    {    for (here = model->UFSinstances; here; here = here->UFSnextInstance)
	 {    if(!here->UFSicVBSGiven) 
	      {  here->UFSicVBS = *(ckt->CKTrhs + here->UFSbNode) 
				- *(ckt->CKTrhs + here->UFSsNode);
              }
              if (!here->UFSicVDSGiven) 
	      {   here->UFSicVDS = *(ckt->CKTrhs + here->UFSdNode) 
				 - *(ckt->CKTrhs + here->UFSsNode);
              }
              if (!here->UFSicVGFSGiven) 
	      {   here->UFSicVGFS = *(ckt->CKTrhs + here->UFSgNode) 
				  - *(ckt->CKTrhs + here->UFSsNode);
              }
              if (!here->UFSicVGBSGiven) 
	      {   here->UFSicVGBS = *(ckt->CKTrhs + here->UFSbgNode) 
				  - *(ckt->CKTrhs + here->UFSsNode);
              }
         }
    }
    return(OK);
}


