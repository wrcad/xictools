/**********
Copyright 1997 University of Florida.  All rights reserved.
Author: Min-Chie Jeng (For SPICE3E2)
File: ufsitf.h
**********/
#ifdef DEV_ufs

#ifndef DEV_UFS
#define DEV_UFS

#include "ufsext.h"

extern IFparm UFSpTable[ ];
extern IFparm UFSmPTable[ ];
extern char *UFSnames[ ];
extern int UFSpTSize;
extern int UFSmPTSize;
extern int UFSnSize;
extern int UFSiSize;
extern int UFSmSize;

SPICEdev UFSinfo = {
    {   "UFS",
        "UF SOI Model",

        &UFSnSize,
        &UFSnSize,
        UFSnames,

        &UFSpTSize,
        UFSpTable,

        &UFSmPTSize,
        UFSmPTable,
    },

    UFSparam,
    UFSmParam,
    UFSload,
    UFSsetup,
    UFSsetup,
    UFStempUpdate,
    UFStrunc,
    NULL,
    UFSacLoad,
    NULL,
    UFSdestroy,
#ifdef DELETES
    UFSmDelete,
    UFSdelete, 
#else /* DELETES */
    NULL,
    NULL,
#endif /* DELETES */
    UFSgetic,
    UFSask,
    UFSmAsk,
#ifdef AN_pz
    UFSpzLoad,
#else /* AN_pz */
    NULL,
#endif /* AN_pz */
#ifdef NEWCONV
    UFSconvTest,
#else /* NEWCONV */
    NULL,
#endif /* NEWCONV */
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,

#ifdef AN_noise
    UFSnoise,
#else   /* AN_noise */
    NULL,
#endif  /* AN_noise */

    &UFSiSize,
    &UFSmSize

};

#endif
#endif

