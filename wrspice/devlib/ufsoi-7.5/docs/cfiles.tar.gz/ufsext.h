/**********
Copyright 1997 University of Florida.  All rights reserved.
Author: Min-Chie Jeng (For SPICE3E2)
File: ufsext.h
**********/

#ifdef __STDC__
extern int UFSacLoad(GENmodel *,CKTcircuit*);
extern int UFSask(CKTcircuit *,GENinstance*,int,IFvalue*,IFvalue*);
extern int UFSconvTest(GENmodel *,CKTcircuit*);
extern int UFSdelete(GENmodel*,IFuid,GENinstance**);
extern void UFSdestroy(GENmodel**);
extern int UFSgetic(GENmodel*,CKTcircuit*);
extern int UFSload(GENmodel*,CKTcircuit*);
extern int UFSmAsk(CKTcircuit*,GENmodel *,int, IFvalue*);
extern int UFSmDelete(GENmodel**,IFuid,GENmodel*);
extern int UFSmParam(int,IFvalue*,GENmodel*);
extern void UFSmosCap(CKTcircuit*, double, double, double, double,
        double, double, double, double, double, double, double,
        double, double, double, double, double, double, double*,
        double*, double*, double*, double*, double*, double*, double*,
        double*, double*, double*, double*, double*, double*, double*, 
        double*);
extern int UFSparam(int,IFvalue*,GENinstance*,IFvalue*);
extern int UFSpzLoad(GENmodel*,CKTcircuit*,SPcomplex*);
extern int UFSsetup(SMPmatrix*,GENmodel*,CKTcircuit*,int*);
extern int UFStempUpdate(GENmodel*,CKTcircuit*);
extern int UFStrunc(GENmodel*,CKTcircuit*,double*);
extern int UFSnoise(int,int,GENmodel*,CKTcircuit*,Ndata*,double*);

#else /* stdc */
extern int UFSacLoad();
extern int UFSdelete();
extern void UFSdestroy();
extern int UFSgetic();
extern int UFSload();
extern int UFSmDelete();
extern int UFSask();
extern int UFSmAsk();
extern int UFSconvTest();
extern int UFStempUpdate();
extern int UFSmParam();
extern void UFSmosCap();
extern int UFSparam();
extern int UFSpzLoad();
extern int UFSsetup();
extern int UFStrunc();
extern int UFSnoise();

#endif /* stdc */

