/**********
Copyright 1997 University of Florida.  All rights reserved.
Author: Min-Chie Jeng (For SPICE3E2)
File: ufsmask.c
**********/

#include "spice.h"
#include <stdio.h>
#include "ifsim.h"
#include "cktdefs.h"
#include "devdefs.h"
#include "ufsdef.h"
#include "sperror.h"
#include "suffix.h"

int
UFSmAsk(ckt, inst, which, value)
CKTcircuit *ckt;
GENmodel *inst;
int which;
IFvalue *value;
{
struct ufsAPI_ModelData *pModel;
UFSmodel *model = (UFSmodel *)inst;
int Error;
double ParamValue;

    pModel = model->pModel;
    if (pModel == NULL)
        return(E_BADPARM);

    switch(which) 
    {   case UFS_MOD_PARAMCHK:
            value->iValue = model->UFSparamChk; 
            return(OK);
        case UFS_MOD_DEBUG:
            value->iValue = model->UFSdebug; 
            return(OK);

	/* Integer Type parameters */ 
	case UFS_MOD_SELFT:
	case UFS_MOD_BODY:
	case UFS_MOD_TPG:
	case UFS_MOD_TPS:
	    Error = ufsGetModelParam(pModel, which, &ParamValue);
	    if (Error)
                return(E_BADPARM);
	    value->iValue = (int) ParamValue;
	    return (OK);

	/* double type parameters */ 
        default:
	    Error = ufsGetModelParam(pModel, which, &ParamValue);
	    if (Error)
                return(E_BADPARM);
	    value->rValue = ParamValue;
    }   

    return(OK);
}

