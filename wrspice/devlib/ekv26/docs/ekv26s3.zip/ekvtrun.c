/*
 * Author: 2000 Wladek Grabinski; EKV v2.6 Model Upgrade
 * Author: 1997 Eckhard Brass;    EKV v2.5 Model Implementation
 *     (C) 1990 Regents of the University of California. Spice3 Format
 */
/*
 */

#include "spice.h"
#include <stdio.h>
#include "cktdefs.h"
#include "ekvdefs.h"
#include "sperror.h"
#include "suffix.h"


int
EKVtrunc(inModel,ckt,timeStep)
GENmodel *inModel;
register CKTcircuit *ckt;
double *timeStep;
{
	register EKVmodel *model = (EKVmodel *)inModel;
	register EKVinstance *here;

	for( ; model != NULL; model = model->EKVnextModel) {
		for(here=model->EKVinstances;here!=NULL;here = here->EKVnextInstance){
			CKTterr(here->EKVqgs,ckt,timeStep);
			CKTterr(here->EKVqgd,ckt,timeStep);
			CKTterr(here->EKVqgb,ckt,timeStep);
		}
	}
	return(OK);
}
