/*
 * Author: 2000 Wladek Grabinski; EKV v2.6 Model Upgrade
 * Author: 1997 Eckhard Brass;    EKV v2.5 Model Implementation
 *     (C) 1990 Regents of the University of California. Spice3 Format
 */

#ifdef __STDC__
extern int EKVacLoad(GENmodel *,CKTcircuit*);
extern int EKVask(CKTcircuit*,GENinstance*,int,IFvalue*,IFvalue*);
extern int EKVdelete(GENmodel*,IFuid,GENinstance**);
extern void EKVdestroy(GENmodel**);
extern int EKVgetic(GENmodel*,CKTcircuit*);
extern int EKVload(GENmodel*,CKTcircuit*);
extern int EKVmAsk(CKTcircuit *,GENmodel *,int,IFvalue*);
extern int EKVmDelete(GENmodel**,IFuid,GENmodel*);
extern int EKVmParam(int,IFvalue*,GENmodel*);
extern int EKVparam(int,IFvalue*,GENinstance*,IFvalue*);
extern int EKVsetup(SMPmatrix*,GENmodel*,CKTcircuit*,int*);
extern int EKVunsetup(GENmodel*,CKTcircuit*);
extern int EKVtemp(GENmodel*,CKTcircuit*);
extern int EKVtrunc(GENmodel*,CKTcircuit*,double*);
extern int EKVconvTest(GENmodel*,CKTcircuit*);
extern int EKVnoise(int,int,GENmodel*,CKTcircuit*,Ndata*,double*);

#else /* stdc */
extern int EKVacLoad();
extern int EKVask();
extern int EKVdelete();
extern void EKVdestroy();
extern int EKVgetic();
extern int EKVload();
extern int EKVmAsk();
extern int EKVmDelete();
extern int EKVmParam();
extern int EKVparam();
extern int EKVsetup();
extern int EKVunsetup();
extern int EKVtemp();
extern int EKVtrunc();
extern int EKVconvTest();
extern int EKVnoise();
#endif /* stdc */
