/*
 * Author: 2000 Wladek Grabinski; EKV v2.6 Model Upgrade
 * Author: 1997 Eckhard Brass;    EKV v2.5 Model Implementation
 *     (C) 1990 Regents of the University of California. Spice3 Format
 */
/*
 */

#include "spice.h"
#include <stdio.h>
#include "util.h"
#include "ekvdefs.h"
#include "sperror.h"
#include "suffix.h"


int
EKVdelete(inModel,name,inst)
GENmodel *inModel;
IFuid name;
GENinstance **inst;
{
	EKVmodel *model = (EKVmodel *)inModel;
	EKVinstance **fast = (EKVinstance **)inst;
	EKVinstance **prev = NULL;
	EKVinstance *here;

	for( ; model ; model = model->EKVnextModel) {
		prev = &(model->EKVinstances);
		for(here = *prev; here ; here = *prev) {
			if(here->EKVname == name || (fast && here==*fast) ) {
				*prev= here->EKVnextInstance;
				FREE(here);
				return(OK);
			}
			prev = &(here->EKVnextInstance);
		}
	}
	return(E_NODEV);
}
