/*
 * Author: 2000 Wladek Grabinski; EKV v2.6 Model Upgrade
 * Author: 1997 Eckhard Brass;    EKV v2.5 Model Implementation
 *     (C) 1990 Regents of the University of California. Spice3 Format
 */
/*
 */

#include "spice.h"
#include <stdio.h>
#include "util.h"
#include "ekvdefs.h"
#include "sperror.h"
#include "suffix.h"


int
EKVmDelete(inModel,modname,kill)
GENmodel **inModel;
IFuid modname;
GENmodel *kill;
{
	EKVmodel **model = (EKVmodel **)inModel;
	EKVmodel *modfast = (EKVmodel *)kill;
	EKVinstance *here;
	EKVinstance *prev = NULL;
	EKVmodel **oldmod;
	oldmod = model;
	for( ; *model ; model = &((*model)->EKVnextModel)) {
		if( (*model)->EKVmodName == modname || 
		    (modfast && *model == modfast) ) goto delgot;
		oldmod = model;
	}
	return(E_NOMOD);

delgot:
	*oldmod = (*model)->EKVnextModel; /* cut deleted device out of list */
	for(here = (*model)->EKVinstances ; here ; here = here->EKVnextInstance) {
		if(prev) FREE(prev);
		prev = here;
	}
	if(prev) FREE(prev);
	FREE(*model);
	return(OK);

}
