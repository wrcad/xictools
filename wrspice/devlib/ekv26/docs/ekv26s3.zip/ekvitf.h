/*
 * Author: 2000 Wladek Grabinski; EKV v2.6 Model Upgrade
 * Author: 1997 Eckhard Brass;    EKV v2.5 Model Implementation
 *     (C) 1990 Regents of the University of California. Spice3 Format
 */
#ifdef DEV_ekv

#ifndef DEV_EKV
#define DEV_EKV

#include "ekvext.h"

extern IFparm EKVpTable[ ];
extern IFparm EKVmPTable[ ];
extern char *EKVnames[ ];
extern int EKVpTSize;
extern int EKVmPTSize;
extern int EKVnSize;
extern int EKViSize;
extern int EKVmSize;

SPICEdev EKVinfo = {
	{
	"EKV",
	"EPLF-EKV v2.6 MOSFET model",

	&EKVnSize,
	&EKVnSize,
	EKVnames,

	&EKVpTSize,
	EKVpTable,

	&EKVmPTSize,
	EKVmPTable,
	DEV_DEFAULT
	},

	EKVparam,
	EKVmParam,
	EKVload,
	EKVsetup,
	EKVunsetup,
	EKVsetup,
	EKVtemp,
	EKVtrunc,
	NULL,
	EKVacLoad,
	NULL,
	EKVdestroy,
#ifdef DELETES
	EKVmDelete,
	EKVdelete,
#else /* DELETES */
	NULL,
	NULL,
#endif /* DELETES */
	EKVgetic,
	EKVask,
	EKVmAsk,
#ifdef AN_pz
	NULL,
#else /* AN_pz */
	NULL,
#endif /* AN_pz */
#ifdef NEWCONV
	EKVconvTest,
#else /* NEWCONV */
	NULL,
#endif /* NEWCONV */

#ifdef AN_sense2
	NULL,
	NULL,
	NULL,
	NULL, 
	NULL,
	NULL,
#else /* AN_sense2 */
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
#endif /* AN_sense2 */
#ifdef AN_disto
	NULL,
#else /* AN_disto */
	NULL,
#endif /* AN_disto */
#ifdef AN_noise
	EKVnoise,
#else /* AN_noise */
	NULL,
#endif /* AN_noise */

	&EKViSize,
	&EKVmSize
};


#endif
#endif
