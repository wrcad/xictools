/*
 * Author: 2000 Wladek Grabinski; EKV v2.6 Model Upgrade
 * Author: 1997 Eckhard Brass;    EKV v2.5 Model Implementation
 *     (C) 1990 Regents of the University of California. Spice3 Format
 */
/*
 */

#include "spice.h"
#include <stdio.h>
#include "util.h"
#include "ekvdefs.h"
#include "suffix.h"


void
EKVdestroy(inModel)
GENmodel **inModel;
{
	EKVmodel **model = (EKVmodel**)inModel;
	EKVinstance *here;
	EKVinstance *prev = NULL;
	EKVmodel *mod = *model;
	EKVmodel *oldmod = NULL;

	for( ; mod ; mod = mod->EKVnextModel) {
		if(oldmod) FREE(oldmod);
		oldmod = mod;
		prev = (EKVinstance *)NULL;
		for(here = mod->EKVinstances ; here ; here = here->EKVnextInstance) {
			if(prev){
				if(prev->EKVsens) FREE(prev->EKVsens);
				FREE(prev);
			}
			prev = here;
		}
		if(prev) FREE(prev);
	}
	if(oldmod) FREE(oldmod);
	*model = NULL;
}
