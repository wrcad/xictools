/***********************************************************************
 HiSIM (Hiroshima University STARC IGFET Model)
 Copyright (C) 2003 STARC

 VERSION : HiSIM 1.2.0
 FILE : hsm1itf.h of HiSIM 1.2.0

 April 9, 2003 : released by STARC Physical Design Group
***********************************************************************/

#ifdef DEV_hisim1

#ifndef DEV_HISIM1
#define DEV_HISIM1

#include "hsm1ext.h"

extern IFparm HSM1pTable[ ];
extern IFparm HSM1mPTable[ ];
extern char *HSM1names[ ];
extern int HSM1pTSize;
extern int HSM1mPTSize;
extern int HSM1nSize;
extern int HSM1iSize;
extern int HSM1mSize;

SPICEdev HSM1info = {
  {   "HiSIM1",
      "Hiroshima University STARC IGFET Model 1.2.0",
      
      &HSM1nSize,
      &HSM1nSize,
      HSM1names,

      &HSM1pTSize,
      HSM1pTable,
      
      &HSM1mPTSize,
      HSM1mPTable,

  },

  HSM1param,
  HSM1mParam,
  HSM1load,
  HSM1setup,
  NULL,
  HSM1setup,
  HSM1temp,
  HSM1trunc,
  NULL,
  HSM1acLoad,
  NULL,
  HSM1destroy,
#ifdef DELETES
  HSM1mDelete,
  HSM1delete, 
#else /* DELETES */
  NULL,
  NULL,
#endif /* DELETES */
  HSM1getic,
  HSM1ask,
  HSM1mAsk,
#ifdef AN_pz
  HSM1pzLoad,
#else /* AN_pz */
  NULL,
#endif /* AN_pz */
#ifdef NEWCONV
  HSM1convTest,
#else /* NEWCONV */
  NULL,
#endif /* NEWCONV */
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,

#ifdef AN_noise
  HSM1noise,
#else /* AN_noise */
  NULL,
#endif /* AN_noise */

  &HSM1iSize,
  &HSM1mSize

};

#endif
#endif
