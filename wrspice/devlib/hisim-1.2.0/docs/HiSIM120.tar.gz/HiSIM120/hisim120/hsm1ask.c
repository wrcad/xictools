/***********************************************************************
 HiSIM (Hiroshima University STARC IGFET Model)
 Copyright (C) 2003 STARC

 VERSION : HiSIM 1.2.0
 FILE : hsm1ask.c of HiSIM 1.2.0

 April 9, 2003 : released by STARC Physical Design Group
***********************************************************************/

#include "spice.h"
#include <stdio.h>
#include "ifsim.h"
#include "cktdefs.h"
#include "devdefs.h"
#include "hsm1def.h"
#include "sperror.h"
#include "util.h"
#include "suffix.h"

int HSM1ask(ckt,inst,which,value,select)
     CKTcircuit *ckt;
     GENinstance *inst;
     int which;
     IFvalue *value;
     IFvalue *select;
{
  HSM1instance *here = (HSM1instance*)inst;

  switch (which) {
  case HSM1_L:
    value->rValue = here->HSM1_l;
    return(OK);
  case HSM1_W:
    value->rValue = here->HSM1_w;
    return(OK);
  case HSM1_AS:
    value->rValue = here->HSM1_as;
    return(OK);
  case HSM1_AD:
    value->rValue = here->HSM1_ad;
    return(OK);
  case HSM1_PS:
    value->rValue = here->HSM1_ps;
    return(OK);
  case HSM1_PD:
    value->rValue = here->HSM1_pd;
    return(OK);
  case HSM1_NRS:
    value->rValue = here->HSM1_nrs;
    return(OK);
  case HSM1_NRD:
    value->rValue = here->HSM1_nrd;
    return(OK);
  case HSM1_TEMP:
    value->rValue = here->HSM1_temp;
    return(OK);
  case HSM1_DTEMP:
    value->rValue = here->HSM1_dtemp;
    return(OK);
  case HSM1_OFF:
    value->iValue = here->HSM1_off;
    return(OK);
  case HSM1_IC_VBS:
    value->rValue = here->HSM1_icVBS;
    return(OK);
  case HSM1_IC_VDS:
    value->rValue = here->HSM1_icVDS;
    return(OK);
  case HSM1_IC_VGS:
    value->rValue = here->HSM1_icVGS;
    return(OK);
  case HSM1_DNODE:
    value->iValue = here->HSM1dNode;
    return(OK);
  case HSM1_GNODE:
    value->iValue = here->HSM1gNode;
    return(OK);
  case HSM1_SNODE:
    value->iValue = here->HSM1sNode;
    return(OK);
  case HSM1_BNODE:
    value->iValue = here->HSM1bNode;
    return(OK);
  case HSM1_DNODEPRIME:
    value->iValue = here->HSM1dNodePrime;
    return(OK);
  case HSM1_SNODEPRIME:
    value->iValue = here->HSM1sNodePrime;
    return(OK);
  case HSM1_SOURCECONDUCT:
    value->rValue = here->HSM1sourceConductance;
    return(OK);
  case HSM1_DRAINCONDUCT:
    value->rValue = here->HSM1drainConductance;
    return(OK);
  case HSM1_VBD:
    value->rValue = *(ckt->CKTstate0 + here->HSM1vbd);
    return(OK);
  case HSM1_VBS:
    value->rValue = *(ckt->CKTstate0 + here->HSM1vbs);
    return(OK);
  case HSM1_VGS:
    value->rValue = *(ckt->CKTstate0 + here->HSM1vgs);
    return(OK);
  case HSM1_VDS:
    value->rValue = *(ckt->CKTstate0 + here->HSM1vds);
    return(OK);
  case HSM1_CD:
    value->rValue = here->HSM1_ids;
    return(OK);
  case HSM1_CBS:
    value->rValue = here->HSM1_ibs;
    return(OK);
  case HSM1_CBD:
    value->rValue = here->HSM1_ibs;
    return(OK);
  case HSM1_GM:
    value->rValue = here->HSM1_gm;
    return(OK);
  case HSM1_GDS:
    value->rValue = here->HSM1_gds;
    return(OK);
  case HSM1_GMBS:
    value->rValue = here->HSM1_gmbs;
    return(OK);
  case HSM1_GBD:
    value->rValue = here->HSM1_gbd;
    return(OK);
  case HSM1_GBS:
    value->rValue = here->HSM1_gbs;
    return(OK);
  case HSM1_QB:
    value->rValue = *(ckt->CKTstate0 + here->HSM1qb); 
    return(OK);
  case HSM1_CQB:
    value->rValue = *(ckt->CKTstate0 + here->HSM1cqb); 
    return(OK);
  case HSM1_QG:
    value->rValue = *(ckt->CKTstate0 + here->HSM1qg); 
    return(OK);
  case HSM1_CQG:
    value->rValue = *(ckt->CKTstate0 + here->HSM1cqg); 
    return(OK);
  case HSM1_QD:
    value->rValue = *(ckt->CKTstate0 + here->HSM1qd); 
    return(OK);
  case HSM1_CQD:
    value->rValue = *(ckt->CKTstate0 + here->HSM1cqd); 
    return(OK);
  case HSM1_CGG:
    value->rValue = here->HSM1_cggb; 
    return(OK);
  case HSM1_CGD:
    value->rValue = here->HSM1_cgdb;
    return(OK);
  case HSM1_CGS:
    value->rValue = here->HSM1_cgsb;
    return(OK);
  case HSM1_CDG:
    value->rValue = here->HSM1_cdgb; 
    return(OK);
  case HSM1_CDD:
    value->rValue = here->HSM1_cddb; 
    return(OK);
  case HSM1_CDS:
    value->rValue = here->HSM1_cdsb; 
    return(OK);
  case HSM1_CBG:
    value->rValue = here->HSM1_cbgb;
    return(OK);
  case HSM1_CBDB:
    value->rValue = here->HSM1_cbdb;
    return(OK);
  case HSM1_CBSB:
    value->rValue = here->HSM1_cbsb;
    return(OK);
  case HSM1_CAPBD:
    value->rValue = here->HSM1_capbd; 
    return(OK);
  case HSM1_CAPBS:
    value->rValue = here->HSM1_capbs;
    return(OK);
  case HSM1_VON:
    value->rValue = here->HSM1_von; 
    return(OK);
  case HSM1_VDSAT:
    value->rValue = here->HSM1_vdsat; 
    return(OK);
  case HSM1_QBS:
    value->rValue = *(ckt->CKTstate0 + here->HSM1qbs); 
    return(OK);
  case HSM1_QBD:
    value->rValue = *(ckt->CKTstate0 + here->HSM1qbd); 
    return(OK);
  default:
    return(E_BADPARM);
  }
  /* NOTREACHED */
}
