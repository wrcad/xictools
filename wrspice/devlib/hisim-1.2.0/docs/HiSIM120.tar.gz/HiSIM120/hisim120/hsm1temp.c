/***********************************************************************
 HiSIM (Hiroshima University STARC IGFET Model)
 Copyright (C) 2003 STARC

 VERSION : HiSIM 1.2.0
 FILE : hsm1temp.c of HiSIM 1.2.0

 April 9, 2003 : released by STARC Physical Design Group
***********************************************************************/

#include "spice.h"
#include <stdio.h>
#include "smpdefs.h"
#include "cktdefs.h"
#include "hsm1def.h"
#include "util.h"
#include "const.h"
#include "sperror.h"
#include "suffix.h"

int HSM1temp(inModel,ckt)
     GENmodel *inModel;
     CKTcircuit *ckt;
{
  /* "ckt->CKTtemp" dependence of HiSIM parameters is treated all in
   * HSM1evaluate102/112/120(). So there is no task in HSM1temp().
   */
  return(OK);
}
