
#ifndef RELEASE_H
#define RELEASE_H

/* Date and version info.  These are rewritten in the FastHenry version
 * supplied with the XicTools.
 **********
 * ACHTUNG! The mkwinpkg file in the packager also has a date code.
 **********
 */
#define FHVERSION "3.0wr"
#define FHDATE "29Sep96, mod 113020"
#define ID_STRING "113020"

#endif

