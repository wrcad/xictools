/*
 * Linear Algebra extensions to FastHenry
 * S. R. Whiteley 12/28/2018 wrcad.com
 */

#ifndef SOLVER_H
#define SOLVER_H

#define matREAL double

typedef struct 
{
    int row;
    double real;
    double imag;
    void *next;
} matColData;


char *matCreate(int, int, int*);
void matSetPureSC(void*, int);
void matSolve(void*, matREAL*, matREAL*);
int matOrderAndFactor(void*, matREAL*, matREAL, matREAL, int);
int matFactor(void*);
void matClear(void*);
matREAL *matGetElement(void*, int, int);
void matSetRowElements(void*, int, matColData*, int);
int matFileMatrix(void*, const char*, const char*, int, int, int);
int matElementCount(void*);
int matFillinCount(void*);

void solver_message();

#endif

