
/*
 *  ERROR DEFINITIONS for the sparse matrix routines.
 *
 *  Author:                     Advising professor:
 *      Kenneth S. Kundert          Alberto Sangiovanni-Vincentelli
 *      UC Berkeley
 *
 *  This file exists solely to make Sparse1.3 upward compatible
 *  from Sparse1.2.  Use of this file is not suggested for use in new
 *  software.
 */

#include "spMatrix.h"
