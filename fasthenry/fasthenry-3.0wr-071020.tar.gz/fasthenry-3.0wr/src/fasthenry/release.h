
#ifndef RELEASE_H
#define RELEASE_H

#define FHVERSION "3.0wr"
#define FHDATE "29Sep96, mod 071020"
#define ID_STRING "071020"

#endif

