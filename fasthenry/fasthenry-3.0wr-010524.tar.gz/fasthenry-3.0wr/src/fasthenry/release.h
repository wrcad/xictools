
#ifndef RELEASE_H
#define RELEASE_H

/* Date and version info.  These are rewritten in the FastHenry version
 * supplied with the XicTools.
 **********
 * ACHTUNG! The mkwinpkg file in the packager also has a date code.
 **********
 */
#define FHVERSION "3.0wr"
#define FHDATE "29Sep96, mod 010524"
#define ID_STRING "010524"

#endif

